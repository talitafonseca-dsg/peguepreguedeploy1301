
import { GoogleGenAI, Type } from "@google/genai";
import { StoryScene, AgeGroup, IllustrationStyle, BibleStory, LanguageCode } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const langMap: Record<LanguageCode, string> = {
  pt: 'Português',
  en: 'English',
  es: 'Español',
  fr: 'Français',
  it: 'Italiano'
};

export async function generateStoryStructure(storyName: string, age: AgeGroup, lang: LanguageCode): Promise<BibleStory> {
  const languageName = langMap[lang];
  
  const prompt = `
    Como um especialista em educação cristã infantil e teólogo, adapte a história bíblica: "${storyName}" para crianças de ${age}.
    Toda a resposta (título, descrições e narração) deve ser estritamente em ${languageName}.
    
    REGRAS:
    1. Divida a história em 8 a 10 fragmentos narrativos claros e cronológicos.
    2. Garanta precisão histórica e teológica: vestimentas da época (túnicas, mantos), cenários do Oriente Médio antigo.
    3. Crie uma "characterDescription": Descrição física EXTREMAMENTE detalhada e consistente do protagonista (cabelo, barba, cor da túnica) para que ele possa ser reconhecido em todas as cenas. (Escreva em ${languageName}).
    4. Para cada fragmento, crie:
       - Um "imagePrompt": Descrição visual clara em INGLÊS focada na ação. Use termos simples e seguros (evite palavras que possam disparar filtros de segurança). Foco em "Biblical scene", "Cute character", "Bright day".
       - Um "narrativeText": O texto que a professora deve ler. Linguagem oral, simples, envolvente. (Em ${languageName}).
    
    Retorne estritamente um JSON:
    {
      "title": "Título da História",
      "characterDescription": "Descrição detalhada",
      "scenes": [
        { "id": 1, "imagePrompt": "string (visual description in English)", "narrativeText": "string (narrative in ${languageName})" }
      ]
    }
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          characterDescription: { type: Type.STRING },
          scenes: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.NUMBER },
                imagePrompt: { type: Type.STRING },
                narrativeText: { type: Type.STRING }
              },
              required: ["id", "imagePrompt", "narrativeText"]
            }
          }
        },
        required: ["title", "characterDescription", "scenes"]
      }
    }
  });

  const data = JSON.parse(response.text || "{}");
  return data;
}

export async function generateSceneImage(
  scenePrompt: string, 
  characterDesc: string, 
  style: IllustrationStyle,
  retryCount = 0
): Promise<string> {
  const stylePrompt = style === IllustrationStyle.STYLE_2D 
    ? "Premium 2D digital sticker illustration style, vivid and vibrant colors, clean thick white outline (sticker effect), simple lines, cheerful lighting."
    : "3D Pixar/Disney style illustration, smooth rendering, volumetric lighting, cute characters with big expressive eyes, soft textures.";

  // Refinando o prompt para ser o mais "seguro" e direto possível para o modelo de imagem
  const finalPrompt = `Biblical children illustration. ${stylePrompt}. Action: ${scenePrompt}. Character details: ${characterDesc}. Environment: Ancient Israel, sun, pure white background. NO text, NO shadows at edges, ONLY the characters and main objects. High quality.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [{ text: finalPrompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    
    // Se não retornou imagem mas não deu erro de exceção, tenta de novo uma vez
    if (retryCount < 1) {
      return generateSceneImage(scenePrompt, characterDesc, style, retryCount + 1);
    }
    
  } catch (error) {
    // Tenta novamente em caso de erro de rede ou timeout
    if (retryCount < 1) {
      console.warn(`Retry attempt ${retryCount + 1} for scene generation...`);
      return generateSceneImage(scenePrompt, characterDesc, style, retryCount + 1);
    }
    throw error;
  }

  throw new Error("Failed to generate image after retries");
}
