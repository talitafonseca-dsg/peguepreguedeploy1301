
import React, { useState, useEffect } from 'react';
import { AgeGroup, IllustrationStyle, StoryScene, BibleStory, LanguageCode, LANGUAGES } from './types';
import { BIBLE_STORIES, ICONS, COLORS } from './constants';
import { generateStoryStructure, generateSceneImage } from './services/gemini';
import { createPrintablePDF } from './components/PDFGenerator';
import { translations } from './translations';

const App: React.FC = () => {
  const [lang, setLang] = useState<LanguageCode>('pt');
  const [selectedStory, setSelectedStory] = useState(BIBLE_STORIES[0]);
  const [customStory, setCustomStory] = useState('');
  const [ageGroup, setAgeGroup] = useState<AgeGroup>(AgeGroup.GROUP_5_6);
  const [style, setStyle] = useState<IllustrationStyle>(IllustrationStyle.STYLE_2D);
  const [darkMode, setDarkMode] = useState(false);
  
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentGenerationPhase, setCurrentGenerationPhase] = useState('');
  const [scenes, setScenes] = useState<StoryScene[]>([]);
  const [characterDescription, setCharacterDescription] = useState('');
  const [generationProgress, setGenerationProgress] = useState(0);

  const t = translations[lang];

  // Toggle Dark Mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      document.body.classList.add('dark');
      document.body.style.backgroundColor = '#0f172a';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.remove('dark');
      document.body.style.backgroundColor = '#fdfaf6';
    }
  }, [darkMode]);

  const handleStartGeneration = async () => {
    const finalStory = customStory.trim() || selectedStory;
    setIsGenerating(true);
    setGenerationProgress(5);
    setCurrentGenerationPhase(t.studyScript);

    try {
      const result: BibleStory = await generateStoryStructure(finalStory, ageGroup, lang);
      setScenes(result.scenes);
      setCharacterDescription(result.characterDescription);
      setGenerationProgress(20);

      const updatedScenes = [...result.scenes];
      for (let i = 0; i < updatedScenes.length; i++) {
        setCurrentGenerationPhase(t.illustratingScene.replace('{0}', (i + 1).toString()).replace('{1}', updatedScenes.length.toString()));
        try {
          const imageUrl = await generateSceneImage(
            updatedScenes[i].imagePrompt, 
            result.characterDescription, 
            style
          );
          updatedScenes[i] = { ...updatedScenes[i], imageUrl, error: undefined };
        } catch (err) {
          console.error(`Error generating image for scene ${i + 1}:`, err);
          updatedScenes[i] = { ...updatedScenes[i], error: 'Error' };
        }
        setScenes([...updatedScenes]);
        setGenerationProgress(20 + ((i + 1) / updatedScenes.length) * 80);
      }
    } catch (err) {
      alert("Error generating content structure. Please try again.");
      console.error(err);
      setIsGenerating(false);
    } finally {
      setIsGenerating(false);
      setGenerationProgress(0);
      setCurrentGenerationPhase('');
    }
  };

  const handleRefreshScene = async (index: number) => {
    const updatedScenes = [...scenes];
    const originalImage = updatedScenes[index].imageUrl;
    
    updatedScenes[index] = { ...updatedScenes[index], loading: true, imageUrl: undefined, error: undefined };
    setScenes([...updatedScenes]);

    try {
      const imageUrl = await generateSceneImage(
        updatedScenes[index].imagePrompt, 
        characterDescription, 
        style
      );
      updatedScenes[index] = { ...updatedScenes[index], imageUrl, loading: false, error: undefined };
      setScenes([...updatedScenes]);
    } catch (err) {
      console.error(`Error refreshing image for scene ${index + 1}:`, err);
      updatedScenes[index] = { ...updatedScenes[index], imageUrl: originalImage, loading: false, error: 'Error' };
      setScenes([...updatedScenes]);
    }
  };

  const handleDownloadPDF = async () => {
    const title = customStory.trim() || selectedStory;
    const validScenes = scenes.filter(s => !!s.imageUrl);
    if (validScenes.length < scenes.length) {
      if (!confirm("Algumas imagens falharam na geração. Deseja baixar o PDF assim mesmo?")) {
        return;
      }
    }
    await createPrintablePDF(title, scenes, lang);
  };

  return (
    <div className={`min-h-screen pb-20 transition-colors duration-500 overflow-x-hidden ${darkMode ? 'dark bg-slate-900 text-slate-100' : 'bg-[#fdfaf6] text-slate-800'}`}>
      
      {/* Decorative floating elements */}
      {!isGenerating && scenes.length === 0 && (
        <div className="fixed inset-0 pointer-events-none overflow-hidden opacity-20 dark:opacity-10">
          <ICONS.Star className="absolute top-20 left-[10%] w-12 h-12 text-yellow-400 animate-pulse" />
          <ICONS.Heart className="absolute top-40 right-[15%] w-10 h-10 text-pink-500 animate-bounce" />
          <ICONS.Star className="absolute bottom-40 left-[15%] w-8 h-8 text-blue-400" />
          <ICONS.Heart className="absolute bottom-20 right-[10%] w-14 h-14 text-orange-400" />
          <div className="absolute top-1/4 left-1/2 w-4 h-4 bg-green-400 rounded-full" />
          <div className="absolute top-1/2 right-1/4 w-6 h-6 bg-purple-400 rounded-full" />
        </div>
      )}

      {/* Header */}
      <header className="bg-white/80 dark:bg-slate-800/80 backdrop-blur-lg border-b-4 border-yellow-400 dark:border-yellow-600 py-3 px-4 mb-8 sticky top-0 z-50 shadow-xl">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 cursor-pointer" onClick={() => { setScenes([]); setCustomStory(''); }}>
            <img 
              src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/pegue-e-pregue-logo.png" 
              alt="Logo Pegue & Pregue" 
              className="h-14 sm:h-16 w-auto drop-shadow-md hover:scale-110 transition-transform"
              onError={(e) => {
                // Fallback se a imagem não carregar (embora devamos assumir que o usuário a colocou)
                (e.target as HTMLImageElement).style.display = 'none';
              }}
            />
            <div className="hidden md:block">
              <h1 className="text-2xl font-black text-slate-800 dark:text-white leading-none tracking-tight">
                Pegue <span className="text-yellow-500">&</span> Pregue
              </h1>
              <p className="text-[10px] text-blue-500 dark:text-blue-400 font-black tracking-[0.2em] uppercase mt-1">{t.subtitle}</p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex bg-slate-100 dark:bg-slate-900 p-1.5 rounded-2xl gap-1 border-2 border-slate-200 dark:border-slate-700 shadow-inner">
              {LANGUAGES.map((l) => (
                <button
                  key={l.code}
                  onClick={() => setLang(l.code)}
                  title={l.label}
                  className={`w-11 h-11 flex flex-col items-center justify-center rounded-xl transition-all ${
                    lang === l.code 
                      ? 'bg-white dark:bg-slate-700 shadow-md text-purple-600 dark:text-purple-400 scale-105 z-10 border border-slate-100 dark:border-slate-600' 
                      : 'text-slate-400 dark:text-slate-500 hover:bg-white/50 dark:hover:bg-slate-800'
                  }`}
                >
                  <span className="text-xl leading-none">{l.flag}</span>
                  <span className={`text-[9px] font-black uppercase mt-0.5 tracking-tighter ${lang === l.code ? 'text-purple-600 dark:text-purple-400' : 'text-slate-400 dark:text-slate-500'}`}>
                    {l.code}
                  </span>
                </button>
              ))}
            </div>

            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="p-2.5 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-yellow-100 dark:hover:bg-yellow-900 transition-all text-lg shadow-sm border-2 border-slate-200 dark:border-slate-700"
            >
              {darkMode ? '☀️' : '🌙'}
            </button>
            
            {scenes.length > 0 && !isGenerating && (
              <button
                onClick={handleDownloadPDF}
                className="bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-2xl font-black flex items-center gap-2 shadow-lg shadow-emerald-200 dark:shadow-none transition-all transform hover:scale-105 active:scale-95 border-b-4 border-emerald-700"
              >
                <ICONS.Download />
                <span className="hidden sm:inline text-sm">PDF</span>
              </button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4">
        {scenes.length === 0 && !isGenerating ? (
          <div className="space-y-12 animate-in fade-in duration-700">
            {/* Main Welcome Card */}
            <div className="bg-white dark:bg-slate-800 p-8 md:p-14 rounded-[3rem] shadow-2xl border-t-8 border-purple-500 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <ICONS.Star className="w-32 h-32 text-yellow-500 rotate-12" />
              </div>

              <div className="relative z-10 flex flex-col md:flex-row items-center gap-10">
                <div className="flex-1 text-center md:text-left">
                  <div className="inline-flex items-center gap-2 bg-yellow-100 dark:bg-yellow-900/40 text-yellow-700 dark:text-yellow-400 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest mb-6">
                    <span className="w-2 h-2 bg-yellow-500 rounded-full animate-ping" />
                    {t.subtitle}
                  </div>
                  <h2 className="text-4xl md:text-5xl font-black text-slate-800 dark:text-white mb-6 leading-tight">
                    {t.prepareClass} <span className="text-purple-600 block sm:inline">✨</span>
                  </h2>
                  <p className="text-slate-500 dark:text-slate-300 text-lg md:text-xl font-medium max-w-lg mb-0 leading-relaxed">
                    {t.prepareDesc}
                  </p>
                </div>
                <div className="w-full md:w-1/3 flex justify-center">
                   <img 
                    src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/pegue-e-pregue-logo.png" 
                    alt="Mascote Logo" 
                    className="w-48 md:w-full max-w-[280px] drop-shadow-2xl hover:rotate-2 transition-transform"
                   />
                </div>
              </div>
            </div>

            {/* Selection Grid */}
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Story */}
              <div className="bg-blue-50 dark:bg-blue-900/20 p-8 rounded-[2.5rem] border-2 border-blue-100 dark:border-blue-800 shadow-sm hover:shadow-md transition-shadow">
                <label className="block text-sm font-black mb-4 flex items-center gap-3 text-blue-700 dark:text-blue-300 uppercase tracking-widest">
                  <span className="bg-blue-500 text-white p-2 rounded-xl"><ICONS.Bible /></span> {t.storyLabel}
                </label>
                <select
                  className="w-full bg-white dark:bg-slate-900 border-b-4 border-blue-200 dark:border-blue-800 rounded-2xl px-4 py-4 focus:border-blue-400 focus:outline-none transition-all text-slate-800 dark:text-white font-bold"
                  value={selectedStory}
                  onChange={(e) => { setSelectedStory(e.target.value); setCustomStory(''); }}
                >
                  {BIBLE_STORIES.map(s => <option key={s} value={s}>{s}</option>)}
                  <option value="Outra...">{t.otherStory}</option>
                </select>
                {selectedStory === "Outra..." && (
                  <input
                    type="text"
                    placeholder={t.otherStory}
                    className="w-full mt-4 bg-white dark:bg-slate-900 border-b-4 border-blue-200 dark:border-blue-800 rounded-2xl px-4 py-4 focus:border-blue-400 focus:outline-none transition-all text-slate-800 dark:text-white font-medium"
                    value={customStory}
                    onChange={(e) => setCustomStory(e.target.value)}
                  />
                )}
              </div>

              {/* Age */}
              <div className="bg-green-50 dark:bg-green-900/20 p-8 rounded-[2.5rem] border-2 border-green-100 dark:border-green-800 shadow-sm hover:shadow-md transition-shadow">
                <label className="block text-sm font-black mb-4 flex items-center gap-3 text-green-700 dark:text-green-300 uppercase tracking-widest">
                  <span className="bg-green-500 text-white p-2 rounded-xl">👶</span> {t.ageLabel}
                </label>
                <div className="grid grid-cols-2 gap-3">
                  {Object.values(AgeGroup).map((age) => (
                    <button
                      key={age}
                      onClick={() => setAgeGroup(age)}
                      className={`px-3 py-3.5 rounded-2xl font-black text-xs border-2 transition-all ${
                        ageGroup === age
                          ? 'bg-green-500 border-green-600 text-white shadow-lg shadow-green-200 dark:shadow-none'
                          : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-700 text-slate-500 dark:text-slate-300 hover:bg-green-100/50'
                      }`}
                    >
                      {age}
                    </button>
                  ))}
                </div>
              </div>

              {/* Style */}
              <div className="bg-orange-50 dark:bg-orange-900/20 p-8 rounded-[2.5rem] border-2 border-orange-100 dark:border-orange-800 shadow-sm hover:shadow-md transition-shadow">
                <label className="block text-sm font-black mb-4 flex items-center gap-3 text-orange-700 dark:text-orange-300 uppercase tracking-widest">
                  <span className="bg-orange-500 text-white p-2 rounded-xl">✨</span> {t.styleLabel}
                </label>
                <div className="flex flex-col gap-3">
                  {Object.values(IllustrationStyle).map((s) => (
                    <button
                      key={s}
                      onClick={() => setStyle(s)}
                      className={`px-4 py-3.5 rounded-2xl font-black text-xs border-2 transition-all text-left flex items-center justify-between ${
                        style === s
                          ? 'bg-orange-500 border-orange-600 text-white shadow-lg shadow-orange-200 dark:shadow-none'
                          : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-700 text-slate-500 dark:text-slate-300 hover:bg-orange-100/50'
                      }`}
                    >
                      {s}
                      {style === s && <span className="bg-white/20 p-1 rounded-lg">✓</span>}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Generate Button Section */}
            <div className="flex flex-col items-center">
              <button
                onClick={handleStartGeneration}
                disabled={isGenerating}
                className="group relative bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-6 px-16 rounded-[2.5rem] font-black text-2xl shadow-2xl shadow-purple-200 dark:shadow-none transition-all transform hover:-translate-y-2 active:scale-95 disabled:opacity-50 overflow-hidden border-b-8 border-blue-800"
              >
                <div className="relative z-10 flex items-center gap-4">
                  <span>{t.generateBtn}</span>
                  <span className="text-3xl animate-bounce">🎨</span>
                </div>
                <div className="absolute top-0 -left-full w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent group-hover:left-full transition-all duration-1000" />
              </button>
              
              <div className="mt-8 bg-yellow-50 dark:bg-yellow-900/20 p-6 rounded-3xl border-2 border-yellow-200 dark:border-yellow-800 flex items-center gap-4 max-w-lg">
                <span className="text-3xl">💡</span>
                <p className="text-yellow-800 dark:text-yellow-200 text-sm font-bold leading-tight">
                  {t.whiteBgTitle}: {t.whiteBgDesc}
                </p>
              </div>
            </div>
          </div>
        ) : isGenerating ? (
          <div className="bg-white dark:bg-slate-800 p-16 rounded-[4rem] shadow-2xl border-b-[16px] border-purple-100 dark:border-slate-700 text-center relative overflow-hidden">
            {/* Background rainbow circle */}
            <div className="absolute -top-20 -left-20 w-64 h-64 bg-yellow-400/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-blue-400/10 rounded-full blur-3xl animate-pulse delay-700" />

            <div className="relative w-48 h-48 mx-auto mb-10">
               <div className="absolute inset-0 bg-purple-500/20 dark:bg-purple-400/20 rounded-full animate-ping"></div>
               <div className="relative w-48 h-48 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center mx-auto shadow-2xl border-8 border-purple-50 dark:border-slate-700 overflow-hidden">
                  <img src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/pegue-e-pregue-logo.png" className="w-4/5 h-auto animate-bounce" />
               </div>
            </div>
            
            <h2 className="text-4xl font-black text-slate-800 dark:text-white mb-4 tracking-tight">{t.generating}</h2>
            <p className="text-slate-500 dark:text-slate-400 mb-12 text-xl font-bold">{currentGenerationPhase}</p>
            
            <div className="max-w-xl mx-auto">
              <div className="w-full bg-slate-100 dark:bg-slate-950 h-8 rounded-full overflow-hidden mb-4 border-4 border-white dark:border-slate-700 shadow-inner p-1">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 via-blue-500 to-green-500 rounded-full transition-all duration-700 ease-out relative" 
                  style={{ width: `${generationProgress}%` }}
                >
                  <div className="absolute top-0 right-0 w-2 h-full bg-white/40 animate-pulse" />
                </div>
              </div>
              <p className="text-slate-400 font-black uppercase text-xs tracking-widest">{Math.round(generationProgress)}% COMPLETO</p>
            </div>
          </div>
        ) : (
          <div className="space-y-20 animate-in slide-in-from-bottom duration-1000">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-8 px-4 py-10 bg-white dark:bg-slate-800 rounded-[3rem] shadow-xl border-l-[12px] border-yellow-400">
              <div className="text-center sm:text-left">
                <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tight leading-tight">
                  {customStory || selectedStory}
                </h2>
                <div className="flex flex-wrap gap-3 mt-5 justify-center sm:justify-start">
                   <span className="bg-purple-600 text-white px-5 py-2 rounded-2xl text-xs font-black uppercase tracking-widest shadow-md">{style}</span>
                   <span className="bg-blue-500 text-white px-5 py-2 rounded-2xl text-xs font-black uppercase tracking-widest shadow-md">{ageGroup}</span>
                   <span className="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-200 px-5 py-2 rounded-2xl text-xs font-black uppercase tracking-widest">{scenes.length} {t.visualLabel}s</span>
                </div>
              </div>
              <button 
                onClick={() => { setScenes([]); setCustomStory(''); }}
                className="bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 px-8 py-4 rounded-2xl font-black text-sm transition-all hover:bg-red-600 hover:text-white border-2 border-red-100 dark:border-red-900/50 shadow-sm"
              >
                ← {t.restartBtn}
              </button>
            </div>

            <div className="grid gap-20">
              {scenes.map((scene, idx) => (
                <div key={scene.id} className="grid lg:grid-cols-2 gap-12 items-stretch group">
                  {/* Visual Side */}
                  <div className="flex flex-col gap-5">
                    <div className="flex items-center justify-between px-4">
                      <div className="flex items-center gap-3">
                        <span className="w-10 h-10 bg-yellow-400 text-white rounded-2xl flex items-center justify-center font-black text-lg shadow-md">{idx + 1}</span>
                        <span className="text-slate-800 dark:text-white text-sm font-black uppercase tracking-widest">
                          {t.visualLabel}
                        </span>
                      </div>
                      {scene.imageUrl && !scene.loading && (
                        <button 
                          onClick={() => handleRefreshScene(idx)}
                          className="p-3 rounded-2xl bg-white dark:bg-slate-800 border-2 border-slate-100 dark:border-slate-700 text-slate-400 hover:text-purple-600 hover:border-purple-200 transition-all shadow-sm"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                          </svg>
                        </button>
                      )}
                    </div>

                    <div className="flex-1 aspect-[3/4] bg-white rounded-[3rem] shadow-2xl border-[16px] border-white ring-4 ring-slate-100 dark:ring-slate-700/50 p-8 flex items-center justify-center relative overflow-hidden group/img cursor-zoom-in">
                      {scene.loading ? (
                         <div className="flex flex-col items-center">
                            <div className="w-20 h-20 border-8 border-purple-100 border-t-purple-600 rounded-full animate-spin mb-6"></div>
                            <span className="text-slate-400 text-sm font-black uppercase tracking-widest">{t.recreating}</span>
                         </div>
                      ) : scene.imageUrl ? (
                        <div className="relative w-full h-full bg-white flex items-center justify-center">
                           <img 
                            src={scene.imageUrl} 
                            alt={`${t.visualLabel} ${idx + 1}`} 
                            className="max-w-full max-h-full object-contain drop-shadow-2xl transition-transform group-hover/img:scale-105 duration-700" 
                           />
                           {/* Rainbow border hint */}
                           <div className="absolute inset-0 border-4 border-dashed border-slate-100 rounded-xl pointer-events-none opacity-50" />
                        </div>
                      ) : scene.error ? (
                        <div className="text-center p-8">
                           <span className="text-6xl block mb-6">🏜️</span>
                           <button 
                            onClick={() => handleRefreshScene(idx)} 
                            className="bg-purple-600 text-white px-8 py-3 rounded-2xl font-black text-sm hover:bg-purple-700 shadow-lg"
                           >
                            {t.tryAgain}
                           </button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                            <div className="w-16 h-16 border-4 border-slate-100 border-t-purple-400 rounded-full animate-spin"></div>
                        </div>
                      )}
                      
                      {/* Recortar icon hint */}
                      <div className="absolute top-4 right-4 bg-slate-100/80 backdrop-blur-sm p-2 rounded-xl opacity-0 group-hover/img:opacity-100 transition-opacity">
                        <span className="text-xs font-black text-slate-500">✂️ PRONTO PARA RECORTAR</span>
                      </div>
                    </div>
                  </div>

                  {/* Text Side */}
                  <div className="flex flex-col gap-5">
                    <div className="flex items-center gap-3 px-4">
                      <span className="bg-blue-500 text-white p-2 rounded-xl">📜</span>
                      <span className="text-slate-800 dark:text-white text-sm font-black uppercase tracking-widest">
                        {t.guideLabel}
                      </span>
                    </div>

                    <div className="flex-1 bg-white dark:bg-slate-800 rounded-[3rem] p-12 border-b-[12px] border-blue-500 shadow-2xl flex flex-col justify-center relative overflow-hidden">
                      <div className="absolute top-0 right-0 p-8 opacity-5">
                         <ICONS.Bible />
                      </div>
                      
                      <div className="relative z-10">
                        <div className="text-blue-500 text-5xl font-black mb-8 opacity-20">“</div>
                        <p className="text-2xl md:text-3xl font-bold text-slate-800 dark:text-white leading-relaxed font-nunito italic -mt-8">
                          {scene.narrativeText}
                        </p>
                        <div className="text-blue-500 text-5xl font-black mt-4 text-right opacity-20">”</div>
                      </div>

                      <div className="mt-12 pt-10 border-t-2 border-slate-100 dark:border-slate-700 relative z-10">
                        <div className="flex items-center gap-3 mb-4">
                           <span className="bg-yellow-100 dark:bg-yellow-900/40 p-2 rounded-lg text-yellow-600">💡</span>
                           <p className="text-xs text-slate-400 dark:text-slate-500 font-black uppercase tracking-widest">{t.pedagogicTip}</p>
                        </div>
                        <p className="text-md text-slate-600 dark:text-slate-300 font-bold px-4 italic leading-relaxed">
                           {t.pedagogicDesc}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Final Download Section */}
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-yellow-400 via-purple-500 to-blue-500 rounded-[4rem] blur opacity-25 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
              <div className="relative bg-white dark:bg-slate-800 p-12 md:p-16 rounded-[4rem] flex flex-col lg:flex-row items-center justify-between gap-10 shadow-2xl border-2 border-white dark:border-slate-700">
                  <div className="text-center lg:text-left flex flex-col md:flex-row items-center gap-8">
                      <img src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/pegue-e-pregue-logo.png" className="w-24 h-24" />
                      <div>
                        <h4 className="font-black text-slate-900 dark:text-white text-4xl mb-3 tracking-tight">{t.finishTitle}</h4>
                        <p className="text-slate-500 dark:text-slate-400 text-xl font-bold">{t.finishDesc}</p>
                      </div>
                  </div>
                  <button
                      onClick={handleDownloadPDF}
                      className="w-full lg:w-auto bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white px-16 py-7 rounded-[2rem] font-black text-2xl flex items-center justify-center gap-4 transition-all transform hover:scale-105 shadow-2xl shadow-emerald-200 dark:shadow-none border-b-8 border-green-800"
                  >
                      <ICONS.Download />
                      <span>{t.downloadBtn}</span>
                  </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-32 text-center px-6 max-w-4xl mx-auto pt-16 border-t-4 border-dotted border-slate-200 dark:border-slate-800">
        <div className="flex flex-col items-center gap-8">
          <img src="https://raw.githubusercontent.com/stackblitz/stackblitz-images/main/pegue-e-pregue-logo.png" className="h-16 w-auto grayscale opacity-50" />
          
          <div>
            <p className="text-slate-400 dark:text-slate-500 text-[11px] font-black uppercase tracking-[0.3em] mb-3">
              {t.footerText}
            </p>
            <p className="text-slate-600 dark:text-slate-300 text-sm font-black tracking-wide">
              {t.copyright}
            </p>
          </div>

          <div className="flex justify-center gap-8 grayscale opacity-30">
             <span className="text-4xl hover:grayscale-0 transition-all cursor-default">⛪</span>
             <span className="text-4xl hover:grayscale-0 transition-all cursor-default">📖</span>
             <span className="text-4xl hover:grayscale-0 transition-all cursor-default">🕊️</span>
             <span className="text-4xl hover:grayscale-0 transition-all cursor-default">🎨</span>
          </div>

          <div className="max-w-lg bg-slate-100 dark:bg-slate-800/50 p-6 rounded-3xl">
            <p className="text-[10px] text-slate-400 dark:text-slate-500 font-bold italic leading-relaxed">
              {t.iaDisclaimer}
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
