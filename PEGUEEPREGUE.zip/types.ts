
export enum AgeGroup {
  GROUP_3_4 = '3–4 anos',
  GROUP_5_6 = '5–6 anos',
  GROUP_7_9 = '7–9 anos',
  GROUP_10_12 = '10–12 anos'
}

export enum IllustrationStyle {
  STYLE_2D = '2D Premium (Vibrante)',
  STYLE_3D = '3D Suave (Disney Style)'
}

export type LanguageCode = 'pt' | 'es' | 'en' | 'fr' | 'it';

export interface Language {
  code: LanguageCode;
  label: string;
  flag: string;
}

export const LANGUAGES: Language[] = [
  { code: 'pt', label: 'Português', flag: '🇧🇷' },
  { code: 'en', label: 'English', flag: '🇺🇸' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
];

export interface StoryScene {
  id: number;
  imagePrompt: string;
  narrativeText: string;
  imageUrl?: string;
  loading?: boolean;
  error?: string;
}

export interface BibleStory {
  title: string;
  characterDescription: string;
  scenes: StoryScene[];
}

export interface GenerationState {
  isGeneratingText: boolean;
  isGeneratingImages: boolean;
  currentStep: number;
  totalSteps: number;
  error?: string;
}
