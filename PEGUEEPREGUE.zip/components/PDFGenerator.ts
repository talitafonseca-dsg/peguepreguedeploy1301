
import { jsPDF } from "jspdf";
import { StoryScene, LanguageCode } from "../types";
import { translations } from "../translations";

export async function createPrintablePDF(title: string, scenes: StoryScene[], lang: LanguageCode) {
  const t = translations[lang];
  const doc = new jsPDF({
    orientation: "p",
    unit: "mm",
    format: "a4"
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const pageHeight = doc.internal.pageSize.getHeight(); // 297mm

  for (let i = 0; i < scenes.length; i++) {
    const scene = scenes[i];

    // Página Ímpar (Frente) -> O Visual
    if (i > 0) doc.addPage();
    
    if (scene.imageUrl) {
      // Para maximizar mantendo margem de ~15mm (conforme pedido inicial)
      // A largura de 180mm deixa 15mm de cada lado (210 - 180 = 30 / 2)
      const imgWidth = 180; 
      const imgHeight = (imgWidth * 4) / 3; // Mantém proporção 3:4 = 240mm
      
      const x = (pageWidth - imgWidth) / 2; // 15mm
      const y = (pageHeight - imgHeight) / 2; // 28.5mm
      
      // Adiciona uma borda fina cinza para guiar o recorte se necessário
      doc.setDrawColor(230, 230, 230);
      doc.rect(x - 0.5, y - 0.5, imgWidth + 1, imgHeight + 1);
      
      doc.addImage(scene.imageUrl, "PNG", x, y, imgWidth, imgHeight);
    }

    // Página Par (Verso) -> O Texto Narrativo
    doc.addPage();
    
    // Título da História no topo do verso
    doc.setFont("helvetica", "bold");
    doc.setFontSize(26);
    doc.setTextColor(124, 58, 237); // Roxo Primary
    doc.text(title, pageWidth / 2, 45, { align: "center" });

    // Indicador de Cena
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(150, 150, 150);
    doc.text(`${t.visualLabel} ${i + 1} / ${scenes.length}`, pageWidth / 2, 60, { align: "center" });

    // Divisor visual simples
    doc.setDrawColor(124, 58, 237);
    doc.setLineWidth(1);
    doc.line(pageWidth / 2 - 20, 70, pageWidth / 2 + 20, 70);

    // Texto Narrativo centralizado
    doc.setFont("helvetica", "italic");
    doc.setFontSize(24);
    doc.setTextColor(20, 20, 20);

    const splitText = doc.splitTextToSize(scene.narrativeText, 160);
    const textHeight = splitText.length * 12; // Altura aproximada baseada no número de linhas
    const textY = (pageHeight - textHeight) / 2 + 10;
    
    doc.text(splitText, pageWidth / 2, textY, { align: "center", lineHeightFactor: 1.4 });

    // Rodapé Institucional e Copyright
    doc.setFontSize(9);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(180, 180, 180);
    doc.text(t.footerText, pageWidth / 2, pageHeight - 20, { align: "center" });
    
    doc.setFontSize(7);
    doc.setTextColor(200, 200, 200);
    doc.text(t.copyright, pageWidth / 2, pageHeight - 15, { align: "center" });
  }

  // Nome do arquivo limpo
  const fileName = title.toLowerCase().replace(/[^\w\s]/gi, '').replace(/\s+/g, '_');
  doc.save(`${fileName}_pegue_e_pregue.pdf`);
}
